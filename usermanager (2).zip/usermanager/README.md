# bootstrap_curd

#### 介绍
springboot+bootstrap实现的增删改查DEMO。供学习交流。

![输入图片说明](https://images.gitee.com/uploads/images/2020/1219/123633_86478547_1505145.gif "bootstrap增删改成.gif")

#### 软件架构
1. 前端：bootstrap4.5+thymeleaf+分页插件
2. 后端：spring boot+mybatisPlus
3. 数据库：mysql


#### 安装教程

1.  git clone
2.  创建数据库bootstrap_curd，并导入工程根目录下的bootstrap_curd.sql
3.  idea打开工程，修改配置文件application.yml中数据库密码
4.  启动工程，访问：localhost:8080

#### 我的博客
持续分享Java全栈干货，欢迎关注 :cn: 

[沙逛鱼技术站](https://cslaoxu.vip)


#### 捐赠
写代码真心不易，请作者喝杯茶，我将不间断奉上更多干货。

![输入图片说明](https://images.gitee.com/uploads/images/2020/1219/130043_65e47540_1505145.png "20200717093241825.png")

