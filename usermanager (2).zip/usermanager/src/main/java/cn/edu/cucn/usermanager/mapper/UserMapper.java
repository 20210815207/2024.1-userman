package cn.edu.cucn.usermanager.mapper;

import cn.edu.cucn.usermanager.model.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface UserMapper extends BaseMapper<User> {

}
