package cn.edu.cucn.usermanager.service;

import cn.edu.cucn.usermanager.model.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**

 **/
public interface UserService extends  IService<User> {

}
