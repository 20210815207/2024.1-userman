package cn.edu.cucn.usermanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootstrapcurdApplicationTests {

    @Test
    void contextLoads() {
    }

}
